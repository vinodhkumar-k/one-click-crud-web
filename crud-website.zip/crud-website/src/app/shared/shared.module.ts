import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatFormFieldModule, MatInputModule, MatIconModule, MatDialogModule, MatChipsModule,
  MatAutocompleteModule, MatTooltipModule, MatButtonModule, MatCheckboxModule
} from '@angular/material';

import { InformationDialogComponent } from './components/information-dialog/information-dialog.component';

@NgModule({
  declarations: [InformationDialogComponent],
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatDialogModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatButtonModule,
    MatCheckboxModule
  ]
})
export class SharedModule { }
