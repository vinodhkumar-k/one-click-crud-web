export const environment = {
  production: true,
  webServerBaseURL : 'https://fmea/api/',
  crudWebServerURL: 'http://10.251.49.12:32166/api'
};
